{
import * as sketch from './jam_1';


// reference sketch to prevent it from being discarded by bundler
// tslint:disable-next-line
sketch;


}